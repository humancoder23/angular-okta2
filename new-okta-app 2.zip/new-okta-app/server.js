const express = require('express');  // Importing the Express.js framework
const session = require('express-session');  // Importing Express session middleware
const path = require('path');  // Importing Node.js path module
const passport = require('./passport/saml');  // Importing custom Passport configuration for SAML
const routes = require('./routes/index');  // Importing routes defined in ./routes/index.js
const bodyParser = require('body-parser');  // Importing body-parser middleware for parsing request bodies
const port = 9992;  // Port number on which the server will listen

const app = express();  // Creating an Express application instance

app.use(express.json());  // Middleware to parse incoming request bodies as JSON
app.use(express.urlencoded({ extended: true }));  // Middleware to parse incoming request bodies with URL-encoded payloads
app.use(bodyParser.urlencoded({ extended: false }));  // Using body-parser middleware for parsing URL-encoded data

app.use(session({
  secret: 'your-generated-secret-key',  // Secret key used to sign the session ID cookie
  resave: false,  // Prevents session from being saved back to the session store on every request
  saveUninitialized: true,  // Forces a session that is "uninitialized" to be saved to the store
  cookie: { maxAge: 600000 }  // Session expires after 10 minutes (600000 milliseconds)
}));

app.use(passport.initialize());  // Initialize Passport middleware
app.use(passport.session());  // Enable persistent login sessions with Passport

app.use(express.static(path.join(__dirname, 'public')));  // Serving static files from the 'public' directory

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);  // Logging HTTP method and URL of incoming requests
  next();  // Passing control to the next middleware function
});

app.use('/', routes);  // Mounting routes defined in ./routes/index.js at the root URL ('/')

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);  // Starting the server and logging the port it's running on
});
