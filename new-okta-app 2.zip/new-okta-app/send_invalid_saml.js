const axios = require('axios');  // Importing Axios library for making HTTP requests
const fs = require('fs');  // Importing Node.js file system module
const path = require('path');  // Importing Node.js path module

// Path to the XML file containing the invalid SAML response
const invalidSamlResponsePath = path.join(__dirname, 'invalid_saml_response.xml');

// Reading the contents of the invalid SAML response XML file as UTF-8 encoded string
const invalidSamlResponse = fs.readFileSync(invalidSamlResponsePath, 'utf-8');

// Function to send the invalid SAML response to a specified endpoint
const sendInvalidSamlResponse = async () => {
  try {
    // Making a POST request to the specified endpoint with the SAMLResponse data
    const response = await axios.post('http://localhost:9992/login/callback', {
      SAMLResponse: invalidSamlResponse  // Sending the invalid SAML response as part of the request body
    });
    console.log('Response:', response.data);  // Logging the response data if request is successful
  } catch (error) {
    // Handling errors if the request fails
    console.error('invalid SAML response:', error.response ? error.response.data : error.message);
  }
};

sendInvalidSamlResponse();  // Calling the function to initiate sending the invalid SAML response
