/**
 * Configuration for SAML integration with Okta.
 * This module exports an object containing various configuration settings needed
 * to integrate the application with Okta's SAML service.
 */
module.exports = {
  // URL to fetch SAML metadata from Okta. This URL typically provides the necessary
  // XML metadata containing information about Okta's SAML endpoints, certificates, etc.
  metadataUrl: 'https://dev-55143921.okta.com/app/exkhc3qf38IMpkefw5d7/sso/saml/metadata',

  // Entry point URL for SAML authentication. This is the URL where the SAML authentication
  // request will be sent. It is provided by Okta and is specific to your application.
  entryPoint: 'https://dev-55143921.okta.com/app/dev-55143921_angularokta_1/exkhc3qf38IMpkefw5d7/sso/saml',

  // The issuer URL identifies the entity issuing the SAML authentication request.
  // This should be a unique identifier provided by Okta for your application.
  issuer: 'http://www.okta.com/exkhc3qf38IMpkefw5d7',

  // Private key used for signing SAML requests (optional). If you are signing SAML requests,
  // include your private key here. Ensure this key is stored securely and not exposed in version control.
  // privateKey: '-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----'
};
