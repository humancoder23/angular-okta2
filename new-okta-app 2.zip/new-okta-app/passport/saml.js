const passport = require('passport'); // Import the passport module for authentication
const SamlStrategy = require('passport-saml').Strategy; // Import the SAML strategy for passport
const axios = require('axios'); // Import axios for making HTTP requests
const xml2js = require('xml2js'); // Import xml2js for parsing XML data
const oktaConfig = require('../config/okta'); // Import Okta configuration from a local config file

async function configurePassport() {
  try {
    // Fetch the SAML metadata from the Okta metadata URL
    const response = await axios.get(oktaConfig.metadataUrl);
    const metadataXml = response.data;

    // Parse the fetched XML metadata
    const parser = new xml2js.Parser();
    const metadata = await parser.parseStringPromise(metadataXml);

    // Extract the certificate from the parsed metadata
    const cert = metadata['md:EntityDescriptor']['md:IDPSSODescriptor'][0]['md:KeyDescriptor'][0]['ds:KeyInfo'][0]['ds:X509Data'][0]['ds:X509Certificate'][0];

    if (!cert) {
      throw new Error('Certificate not found in metadata'); // Throw an error if the certificate is not found
    }

    // Configure the SAML strategy with the necessary parameters
    passport.use(new SamlStrategy({
      path: '/login/callback', // URL to handle SAML callback
      entryPoint: oktaConfig.entryPoint, // URL to which the SAML request is sent
      issuer: oktaConfig.issuer, // The entity ID of the SAML issuer (Okta)
      cert: cert, // The certificate extracted from the metadata
      validateInResponseTo: true, // Validate the 'InResponseTo' field to prevent replay attacks
      disableRequestedAuthnContext: true, // Disable the AuthnContext request (optional)
      signatureAlgorithm: 'sha256' // Use SHA-256 for signing
    }, (profile, done) => {
      console.log('SAML Profile:', profile); // Log the SAML profile

      // Check if the profile is valid (indicating successful signature verification)
      if (profile) {
        console.log('SAML signature verification was successful.');
        return done(null, profile); // Pass the profile if verification is successful
      } else {
        console.log('SAML signature verification was unsuccessful.');
        return done(new Error('SAML signature verification failed'), null); // Return an error if verification fails
      }
    }));

    // Serialize the user to the session
    passport.serializeUser((user, done) => {
      done(null, user);
    });

    // Deserialize the user from the session
    passport.deserializeUser((user, done) => {
      done(null, user);
    });
  } catch (error) {
    console.error('Error fetching metadata:', error); // Log any errors that occur during metadata fetch
    process.exit(1); // Exit the process if there's an error
  }
}

configurePassport(); // Execute the configurePassport function to set up passport with SAML

module.exports = passport; // Export the configured passport instance
