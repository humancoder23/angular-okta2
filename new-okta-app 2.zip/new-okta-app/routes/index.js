const express = require('express'); // Import the express module to create routes
const passport = require('../passport/saml'); // Import the configured passport instance with SAML strategy
const router = express.Router(); // Create a new router instance
const path = require('path'); // Import the path module to handle file paths

// Middleware to check if the session has expired
function checkSession(req, res, next) {
  if (!req.session || !req.session.passport || !req.session.passport.user) {
    return res.redirect('/'); // Redirect to home if the session is invalid or expired
  }
  next(); // Proceed to the next middleware or route handler if session is valid
}

// Default route to serve login.html
router.get('/', (req, res) => {
  const loginPath = path.join(__dirname, '../public', 'login.html');
  res.sendFile(loginPath, (err) => {
    if (err) {
      console.error('Error serving login.html:', err);
      res.status(err.status).end(); // End the response if there's an error
    }
  });
});

// SAML login route
router.get('/login', passport.authenticate('saml', { failureRedirect: '/', failureFlash: true }), (req, res) => {
  res.redirect('/'); // Redirect to home after successful authentication
});

// SAML login callback route
router.post('/login/callback', (req, res, next) => {
  console.log('POST /login/callback');
  console.log('Received SAML Response:', req.body.SAMLResponse); // Log the received SAML response for debugging

  // Authenticate the SAML response
  passport.authenticate('saml', (err, user, info) => {
    if (err) {
      console.error('SAML authentication error:', err);
      return res.status(401).send('SAML authentication error'); // Send error response if authentication fails
    }
    if (!user) {
      console.error('SAML authentication failed:', info);
      return res.status(401).send('SAML authentication failed'); // Send error response if user is not authenticated
    }
    req.logIn(user, (err) => {
      if (err) {
        console.error('Login error:', err);
        return res.status(401).send('Login error'); // Send error response if login fails
      }
      return res.redirect('/website'); // Redirect to the protected route after successful login
    });
  })(req, res, next);
});

// Route for website.html, protected by session check middleware
router.get('/website', checkSession, (req, res) => {
  const websitePath = path.join(__dirname, '../public', 'website.html');
  res.sendFile(websitePath, (err) => {
    if (err) {
      console.error('Error serving website.html:', err);
      res.status(err.status).end(); // End the response if there's an error
    }
  });
});

// Route for index.html
router.get('/index', (req, res) => {
  const indexPath = path.join(__dirname, '../public', 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error('Error serving index.html:', err);
      res.status(err.status).end(); // End the response if there's an error
    }
  });
});

// Logout route
router.get('/logout', (req, res) => {
  console.log('GET /logout');
  req.logout(err => {
    if (err) {
      console.error('Error during logout:', err);
      return res.redirect('/'); // Redirect to home if there's an error during logout
    }

    req.session.destroy(err => {
      if (err) {
        console.error('Error destroying session:', err);
        return res.redirect('/'); // Redirect to home if there's an error destroying the session
      }
      console.log('Session destroyed. Redirecting to Okta logout.');
      const oktaLogoutUrl = 'https://dev-55143921.okta.com/login/signout?post_logout_redirect_uri=http://localhost:9992/login';
      res.redirect(oktaLogoutUrl); // Redirect to Okta logout URL after destroying the session
    });
  });
});

// Catch-all route to serve login.html for any other routes
router.get('*', (req, res) => {
  const loginPath = path.join(__dirname, '../public', 'login.html');
  res.sendFile(loginPath, (err) => {
    if (err) {
      console.error('Error serving login.html:', err);
      res.status(err.status).end(); // End the response if there's an error
    }
  });
});

module.exports = router; // Export the router instance for use in the main app
